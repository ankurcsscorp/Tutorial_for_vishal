function My_Promise() {
    return new Promise((resolve, reject) =>{
    setTimeout( ()=>{
        const error = true;
        if(!error){
            console.log("Function : Your Promise has been resolved")
            resolve();
        }
        else{
            console.log("Function : Your Promise has not been resolved");
            reject();
        }
    }, 2000);
    })
}

// Now calling the function

My_Promise().then(()=>{
    console.log("Ankur: Thanks for Resolving")
}).catch(()=> {
    console.log("Ankur: Very bad bro...")
})