//Fibonocci number
let sum;
let count=0;
let memo=[];
const fib=(n) => {
    
if(memo[n]!= null)
{
    return memo[n];
}
count++;
    if(n<0)
    {
        return console.log("Error");
    }
    if(n==0){
        return 0;
    }
    if(n==1){
        return 1;
    }
    sum= fib(n-1)+ fib(n-2);
    memo[n]=sum;
    return sum;
}

fib(10);
console.log(sum);
console.log(count);

// Bottom to Top Method
// let c=0;
let Fibonocci=(n) => {
    // c++;
    let array=[];   
    array[0]=0;
    array[1]=1;
    for(let i= 2; i<=n; i++){
        array[i]= array[i-1]+array[i-2];
    }
    return console.log(array[n]);
}

Fibonocci(10);
// console.log(c);