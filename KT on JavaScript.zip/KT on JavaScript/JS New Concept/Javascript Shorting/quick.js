// let array= [6,7,8,2,4,6,7,1];

let partation = (array,lb,ub) => {
    let pivot,start,end;
        pivot=array[lb];
        start=array[lb];
        end=array[ub];
    
        while(start<end)
        {
            while(array[start]<pivot)
            {
                start++;
            }
            while(array[end]> pivot)
            {
                end--;
            }
            if(start<end) {
                let temp=array[start];
                array[start]=array[end];
                array[end]=temp;
            }
        }
        let temp= array[lb];
        array[lb]= array[ub];
        array[ub]=temp;
    }
let quickSort= (array,lb,ub) => {
     array= [6,7,8,2,4,6,7,1];
if(lb<ub)
{
    loc=partation(array,lb,ub);
    quickSort(array,lb,loc-1);
    quickSort(array,loc+1,ub);
}
array.forEach(element => {
    console.log(element);
});
}
