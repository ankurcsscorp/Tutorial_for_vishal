// Working with Objects
let stage= {
    performer: "Rahul kumar yadav",
    number: 7,
    show: function() {
        console.log("Dance program Particepents " + this.performer.split(' ')[0]);
    }
}
// stage.show();

// lets see class and constrecter

class Test {
    constructor(){
        this.name="Ankur";
    }
}
// console.log(Test.name)

//Now we will the Array methods
var arr= [1,2,3,4];
arr.push(5);
arr.unshift(01)
arr.pop();
arr.shift();
arr.splice(1,2)
// console.log(arr)

function mapMethod() {
    let arr= [10,20,100,144];
    // let new_arr= arr.map(Math.sqrt);
    var new_arr= arr.map(function(num){
        return num/2
    })
    console.log(new_arr)
}
// mapMethod();

function findIndexMethod()
{
    var arr= [-1,-5,-10, ,45,5,22,33];
    var new_arr= arr.findIndex(function(num)
    {
        return num>0;
    })
    console.log(new_arr)
}
// findIndexMethod();

function arrayJoin()
{
    let arr= [1,2,3,4,5];
    // console.log(arr.join(' | '))
    console.log(arr.fill(55, 0,3))
}
// arrayJoin();

// Array form

function arrayForm()
{
    let str= "ANKURKUMARSINGH";
    console.log(Array.from(str))
}
// arrayForm();

// Find method

let arrFind = () => {
    let arr= [-1,-2,-3,2,4,1];
    var found= arr.find(function(e)
    {
        return e> 0
    })
    console.log(found)
}
// arrFind();

// Array to string method

function arrToString()
{
    let arr= [1,2,3,4,5];
    console.log(arr.toString())
}
// arrToString();

// Reverse array

let revArray= () => {
let array= ["how", "are", "you"];
console.log(array.reverse())
}
// revArray();

// Array Short method

let arraySort = () => {
    let array= [1,15,3,17,2];
    let new_ar= array.sort(function(a,b){
        return a-b;
    })
    console.log(new_ar);
}
// arraySort();

// Now we will see the String methods

function TestString(){
    let str="  my name is Ankur     ";
    // let sub= str.substr(3);
    console.log(str.length)
    let trimStr= str.trim()
    console.log(trimStr)
    console.log(trimStr.length)
} 
// TestString()

// Callback function example

function callBackEx(arr, callback)
{
    arr.push(11);
    callback();
}
var arr= [1,2,3,4,5];
callBackEx(arr, function()
{
    // console.log("Array is modified "+ arr)
})

// reverse the string

function revStr(str)
{
    var revSantence= str.split("").reverse().join("");
    var revStr= revSantence.split(" ").reverse().join(" ");
    
    console.log(revStr)
}

var str= "Welcome to this Javascript Guide!";
// revStr(str);

// Check the object is Array or not

function checkArray()
{
    var arr= [1,2,3];
    if(Object.prototype.toString.call(arr) === '[object Array]')
    {
        console.log("Array")
        console.log(Object.prototype.toString.call(arr))
    } else{
        console.log("This is not an Array")
    }
}
// checkArray();

// Create base element and add number
function createBase(baseNumber)
{
    return function(N)
    {
        return baseNumber+N;
    }
}
var addSix= createBase(6);
// console.log(addSix(20));

// Fizzbuzz chalamge

function fizzBuzzChalange()
{
    for(var i=1; i<=100;i++)
    {
        if(i%3==0 && i%5==0)
        {
            console.log(i+" FizzBull");
        }
        else if(i%5==0)
        {
            console.log(i+" Fizz");
        }
        if(i%3==0)
        {
            console.log(i+" Bull");
        }
    }
}
// fizzBuzzChalange();

// Check the Annagram



function isAnnagram(first, second)
{
    var a= first.toLowerCase();
    var b = second.toLowerCase();
    a= a.split("").sort().join("");
    b= b.split("").sort().join("");
    return a==b
}
var firstWord= "Army";
var secondWord= "Mary";
// console.log(isAnnagram(firstWord, secondWord));

function multiply(a)
{
    return function(b)
    {
        return a*b;
    }
}
console.log(multiply(12)(5))

