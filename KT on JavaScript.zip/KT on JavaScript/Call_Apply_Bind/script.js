let name = {
    firstName : "Ankur",
    lastName: "Kumar",
}
 let printFullName = function(hometown, state){
    console.log(this.firstName+" "+this.lastName+ " From "+ hometown+ " State: "+ state)
}
// Call method

//With the call() method, you can write a method that can be used on different objects.
//Call method always returns a annoniumos function
printFullName.call(name," Patna", "Bihar" );

let name2 = {
    firstName: "Sundar",
    lastName: "Pichai",
}
printFullName.call(name2," Chennai","TamilNadu");

//Apply Method
// With the apply() method, you can write a method that can be used on different objects.
// Diffrence from call to apply is , we can pass the argument as a bundle like array. no need to pass the the value induvisually.
printFullName.apply(name2, ["Chennai","TamilNadu"]);

//Bind Method
//The diffrence between bind with call and apply is, It will bind the method and we can use that method later . we cant use that method isstand like call and bind.

let bindMethod= printFullName.bind(name," Patna", "Bihar" );

bindMethod();
