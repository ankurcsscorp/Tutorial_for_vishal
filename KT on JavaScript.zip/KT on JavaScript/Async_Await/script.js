// setTimeout(() => {
//     for (let index = 1; index < 200; index++) {
//         console.log(index)  
//     }
// }, 100);
// console.log("Done")

// Let's Explore Async Await

async function fetchData()
{
    console.log("Came inside fetchData Method");
    const response= await fetch('https://api.github.com/users');
    console.log("Before resopnse the API");
    const user = await response.json();
    console.log("User resolved");
    return user;  
}
let a= fetchData();
console.log("After calling Fetch Data");
a.then(data => console.log(data));

console.log("Last line of the JS file");