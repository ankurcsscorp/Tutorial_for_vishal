// Fetch Method Practice
let allData=[];
const fetchMethod = () => 
{
    fetch('https://api.github.com/users/hadley/orgs')
    .then((response) => {
        return response.json();
    }).then((data) => {
        allData= data;
       console.log(allData);
       var names= allData.map((i) => {
           return console.log(i.login);
       })
    })
}


