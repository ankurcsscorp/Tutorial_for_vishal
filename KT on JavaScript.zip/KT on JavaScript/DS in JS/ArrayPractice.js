function revArray()
{
    let array= [1,2,3,4,5];
    for(let i=array.length-1; i>=0; i--)
    {
      console.log(array[i])
    }
}
// revArray();

//Find Sum of Sub array

function SumOfSubArray()
{
    let array=[2,4,6,9,1,10,5,10,4];
    let sum=19;
    
    for(let i=0; i<array.length;i++)
    {
        let currentSum= array[i];
        for(let j=i+1; j< array.length;j++)
        {
            currentSum+= array[j];
            if(currentSum == sum)
            {
                console.log("matched array of sum")
                for(let k=i; k<=j; k++)
                {
                    console.log(array[k])
                    
                }
                
            }
        }
    }
}
// SumOfSubArray();

function fun()
{
    window.open('https://confluence.esteeonline.com/login.action?os_destination=%2Findex.action&permissionViolation=true', '_blank');
//    document.getElementById("os_username").value="ankkumar";
   document.getElementById("os_username").value = "Johnny Bravo";
}
// window.onload=funn;