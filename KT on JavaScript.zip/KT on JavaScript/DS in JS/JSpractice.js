// let person= function(name, age){
//     this.name=name;
//     this.age=age;
//     this.info= function(){
//         setTimeout(() =>
//         {
//             document.write(this.name +" is " +this.age+" years old");
//             },3000);
        
//     }
// }
let arr= [4,5,75,33,44,12,34,35,37];
let str= ["kumar", "kumar", "dsbfd", "kumar", "kumar","sjfj77"];
//Iterate using forEach loop

// arr.forEach(array=>{
//     console.log(array);
// });

//filter array which is more the 30

// let filterMethod = arr.filter(function(array){
//     if(array>= 30){
//         return true
//     }
// })
let filterMethod= arr.filter(array=> array >= 30);
console.log(filterMethod);

//filter string

let filterString = str.filter(array=> array==="kumar");
console.log(filterString);

// map method with string

let mapMethod= str.map(function(array){
    return `${array} `;
})
console.log(mapMethod);

//Map in number array
let  numArray = arr.map(array=> array*2)
.map(array=> array/2)
.map(abc=> abc+1);
console.log(numArray); 

//sorting the array

// let sortArray= arr.sort((a,b) => (a>b) ? 1 : -1);
// let sortArray= arr.sort((a,b)=> b-a);
let sortArray =arr.sort((a,b)=> b-a );
console.log(sortArray);

//reduce function

let reduceMethod= arr.reduce((total, array) => total+array, 0);
console.log(reduceMethod);

