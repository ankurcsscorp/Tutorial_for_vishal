// main row element to show the hotel list
let mainRow = document.getElementById("HotelList");
// error message element to show the message likr no search, no favourite etc
let errorMessageElement = document.getElementById("notificationMessage");
// select dropdown for sort using event delegation
let selectSorting = document.getElementById("dropdown-sort");
// select dropdown for filter using event delegation
let selectFilter = document.getElementById("dropdown-filter");

// to copy the hotels once my page is loaded
let allHotelsDataCopy = [];

// getting data using fetch form API folder
let getData = () => fetch("https://run.mocky.io/v3/bcbc592e-6190-4009-b554-7d9471482220").then(data => data.json());

// returns single hotel card
let getHotelCard = singleHotelData => {
    // check on loading the view whether the hotel already in local storage then change class to show favourite icon red already
    let a = JSON.parse(localStorage.getItem('fav'));
    if (a !== null) {
        var favIconClass = (!a.find(hotel => hotel.id == singleHotelData.id)) ? "fa-heart" : "fa-heart-red";
    } else {
        var favIconClass = "fa-heart"
    }
    //  console.log(singleHotelData);
    return `<div class="col-md-3">
      <div class="card">
        <img class="card-img-top" src="${singleHotelData.img}" alt="Card image">
        <div class="card-body">
          <h6 class="card-title">${singleHotelData.name}</h6>
          <p class="card-text tags" >${singleHotelData.tags}</p>
          <a onclick="markFavourite(this, ${singleHotelData.id})" id="${favIconClass}"><i class="fa fa-heart" ></i><a>
          <div>
            <div class="rating">
                <span class="fa fa-star checked" > ${singleHotelData.rating} </span>
            </div>
             <span class="eta"> ${singleHotelData.eta} MINS </span>
              <a href="#" class="view-menu" >View Menu</a>
              </div>
        </div>
      </div>
</div>`;

}

// generate view
let generateView = data => data.map(hotel => getHotelCard(hotel));

// display all the hotels  
let displayAllHotels = () => {
    getData()
        .then(data => {
            allHotelsDataCopy = JSON.parse(JSON.stringify(data));// not use for display
            mainRow.innerHTML = generateView(data).join('');
            console.log(data);
        })
        .catch(error => errorMessageElement.innerText = "Something bad Happend!! We are Working on it")
}

displayAllHotels();
