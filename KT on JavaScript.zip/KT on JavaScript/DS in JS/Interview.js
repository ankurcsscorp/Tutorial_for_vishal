function missing(n){
let array = [1,2,3,5,6,7,8,9,10];

let sum= n*(n+1)/2;
let  total = array.reduce((t,i)=> t+i);
return console.log(sum-total);
}


// missing(10);

// Reverse the string

let strRev = () => {

    let str= "I love JavaScript";
    let revsp= str.split(" ").reverse().join(" ");
    let rev= str.split("").reverse().join("");
    console.log(str);
    console.log(revsp);
    console.log(rev);
}
// strRev();

// sum of array in one index

let sumOfArray = () => {
    let array= [1,2,3,4];
    let newArray=[];
    for(let i=0; i< array.length; i++)
    {
        let sum=0;
        for(let j=0; j< array.length;j++)
        {
            if(i!=j && j< array.length)
            {
                sum+= array[j];
                newArray[i]= sum;
            }
        }
    }
    let big=newArray[0];
    let small= newArray[0];
    for(let i=0; i< newArray.length; i++){
        if(newArray[i]> big)
        {
            big= newArray[i];
        }else if(newArray[i]< small)
        {
            small= newArray[i]
        }
        console.log(newArray[i]);

    }
    console.log("Big array "+ big);
    console.log("Small array "+small);
}
// sumOfArray();

// Second Approch

let arr= [1,2,3,4];
let findMinMax = (array) => {
    let minNumber= Math.min.apply(null, array);
    let maxNumber= Math.max.apply(null, array);

    let sum= array.reduce((acc, ind) => acc+ind);

    let minSum= sum-minNumber;
    let maxSum= sum-maxNumber;
   return {minSum: maxSum, maxSum: minSum};
}
// console.log(findMinMax(arr));

//Count the length of the numver

// let num= 12345;
// function totalLength(num)
// {
//     numb= parseInt(num);
//     let len=0;
//     while(numb>=0)
//     {
//         numb= numb/10;
//         console.log(numb);
//         len++
//     }
//     return len;
// }
// console.log(totalLength(num));

// Find the maximum number and count how amny times it is repeted

let FindMax = (array) => {
    let maxnum= Math.max.apply(null, array);
    // console.log(maxnum);
    let count=0;
    for(let i=0;i<array.length;i++)
    {
        if(array[i]== maxnum)
        {
            count++;
        }
        
    }
    return count;
}
let array=[2,3,4,1,2,2,4];
// console.log(FindMax(array));
// Print not between 1-100
//multiple of 3 - fizz
//multiple of 5- buzz
// multiple of 3 & 5- fizzbuzz

let PrintNumber = (n) => {

    for(let i=1; i<=n; i++)
    {
        if(i%3==0 && i%5==0)
        {
            console.log("fizzbuzz");
        }
        else if(i%3==0)
        {
            console.log("fizz");
        }
        else if( i%5==0)
        {
            console.log("buzz");
        }
        else{
            console.log(i);
        }
    }
}
PrintNumber(100);


