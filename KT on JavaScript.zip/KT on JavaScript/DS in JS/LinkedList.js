class Node {
    constructor(data, next=null) {
        this.data=data;
        this.next=next;
    }
}

    class linkedList {
        constructor()
        {
            this.head=null;
            this.size=0;
        }
        //Insert First
        insetFirst(data){
            this.head= new Node(data, this.head);
            this.size++;
        }
//print list data
printListData()
{
    let current= this.head;
    while(current != null){
        console.log(current.data);
        current=current.next;
    }
}

//Insert last
insertLast(data){
    let node = new Node(data);
    let current;
    if(this.head==null){
        this.head= node;
    }else 
    {
        current= this.head
        while(current.next != null)
        {
            current=current.next;
        }
        current.next=node;
    }
    this.size++;
}
//Insert anywhere
insertAt(data, index){
    //Index out of range
    if(index > 0 && index > this.size)
    {
        return;
    }
    if(index===0) {
        this.insetFirst(data);
        return;
    }
    const node = new Node(data);
    let current, previous;
    current=this.head;
    let count=0;
    while(count < index) {
        previous= current;  // node before index
        count++;
        current=current.next;  //node after index

    }
    node.next=current;
    previous.next=node;
    this.size++;
}
//Delete from begining
deleteFromBegining(){
    this.head= this.head.next;
    this.size--;
}
//Delete from last
deleteFromLast(){
    let temp= this.head;
    let prev;
    while(temp.next != null)
    {
        prev= temp;
        temp= temp.next;
    }
    if(temp==this.head)
    {
        this.head=0;
    }else {
        prev.next=0;
    }
    this.size--;
    }

//Delete At
deleteAt(index) {
let i=0, temp= this.head;
let prev=temp;
//Index out of range
if(index > 0 && index > this.size)
{
    return;
}
else{
    while(i<index)
    {
        prev= temp;
        temp=temp.next;
        i++;
    }
    prev.next= temp.next;
    this.size--;
    }
  }
  //Find the Length of Linked List
  getLength()
  {
      let temp=this.head;
      let count=0;
      while(temp != null)
      {
          count++;
          temp=temp.next;
      }
      console.log("The length of linked list is : "+count);
  }
  // Reverse the linked list
  reversedLinkedList()
  {
      let prevnode, currentnode, nextnode;
      currentnode=nextnode=this.head;
      prevnode=0;
      while(nextnode !=null)
      {
          nextnode= nextnode.next;
          currentnode.next=prevnode;
        //   nextnode.next=currentnode;
          prevnode=currentnode;
          currentnode=nextnode;
      }
      this.head=prevnode;
  }
  //Search and exesting elemnet
  searchElement(dataa){
let temp= this.head;
let counter=1;
while(temp.data !=dataa){
temp= temp.next;
counter++;
}
console.log("The data "+dataa+" present at node number : "+counter )
  }
  //find the middle value from the linked linst
  middleValue()
  {
      let temp= this.head;
      let indexVal= this.head;
      let count= 0, i=1;
      while(temp.next!=0)
      {
          temp= temp.next;
          count++;
      }
      let indexValue= (count/2);
      while(i< indexValue)
      {
        indexVal= indexVal.next;
        i++;
      }
      console.log("The middle element of this linked list is : "+indexVal.data+" and the node number is: "+i)
  }
}
    const ll= new linkedList();
    ll.insetFirst(10);
    ll.insetFirst(20);
    ll.insetFirst(30);
    ll.insetFirst(40);
    // ll.printListData();
    ll.insertLast(50);
    ll.insertAt(100, 0);
    // ll.deleteFromBegining();
    // ll.deleteFromLast();
    // ll.deleteAt(2);
    ll.getLength();
    ll.printListData();
    ll.reversedLinkedList();
    console.log("reversed linked list");
    ll.printListData();
    console.log("Search result");
    ll.searchElement(40);
    ll.middleValue()
    
