// arrow function

/*let colors= ['red', 'blue', 'green'];
let color= colors.map(col=> `<li>${col}</li>`);
console.log(color);*/

// Use of classes

// class Person {
//     constructor(name) {
//         this.name=name;
//     }
//     walk()
//     {
//         console.log(this.name+ " is walking.");
//     }
// }
// const person = new Person("Ankur");
// person.walk();

// const person = 
// {
//     walk()
//     {
//         console.log("person1")
//     }
// }
// const person2 =
// {
//     walk()
//     {
//         console.log("person2")
//     }
// }

// person.walk();
// person.walk();

//Classes and constructor

class person{
    constructor(name){

    }
    walk()
    {
        console.log(this.name=name)
    }
}


